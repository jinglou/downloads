%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% SED2_GT generates the binary masks of the evaluation database SED2 for saliency evaluation. 
% 
% If you use this code or data, please cite our paper: 
% 
% Jing Lou, Mingwu Ren, Huan Wang, "Regional Principal Color Based Saliency Detection," PLoS ONE, 
% vol. 9, no. 11, pp. e112475: 1-13, 2014. doi:10.1371/journal.pone.0112475
% 
% Project page: http://www.loujing.com/rpc-saliency/
% 
% Copyright (C) 2016 Jing Lou (http://www.loujing.com)
% ------------------------------------------------------------------------------------------------------
% 
% 
% Folders
% --------------------------------------------
% SED2:		original evaluation database (http://www.wisdom.weizmann.ac.il/~vision/Seg_Evaluation_DB/index.html)
% SED2_GT1:	ground truth approved unanimously (recommendation)
% SED2_GT2:	ground truth approved by more than half
% 
% 
% Acknowledgment
% --------------------------------------------
% I would like to thank Dr. Ming-Ming Cheng (http://mmcheng.net) for his helpful suggestions.
% 
% 
% References
% --------------------------------------------
% [1] S. Alpert, M. Galum, R. Basri, and A. Brandt, "Image segmentation by probabilistic bottom-up aggregation and cue integration," 
%     in Proc. IEEE Conf. Comput. Vis. Pattern Recognit., 2007, pp. 1�C8.
% [2] A. Borji, D. N. Sihite, and L. Itti, "Salient object detection: A benchmark," in Proc. Eur. Conf. Comput. Vis., 2012, 
%     pp. 414�C429.
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clc; clear; close all;

load('SED2\img_list.mat');
for fileno = 1:length(fls)
	name = fls(fileno).name;
	
	% for each input image, generate a single map (DOUBLE) from all the human segmentation results
	segfls = dir(['SED2\',name,'\human_seg\*.png']);
	fprintf('\t%03d/%d - %dp - %s\n',fileno,length(fls),length(segfls),name);
	for segno = 1:length(segfls)
		segimg = imread(['SED2\',name,'\human_seg\',segfls(segno).name]);
		if ~exist('segmap','var')
			segmap = zeros(size(segimg,1),size(segimg,2));
		end
		R = segimg(:,:,1);
		G = segimg(:,:,2);
		B = segimg(:,:,3);
		ind = ((R>G)&(R>B)) | ((B>R)&(B>G));	% Red or Blue
		segmap = segmap + double(ind);
	end
	
	% Ground Truth 1: approved unanimously (recommendation)
	GT1 = segmap==length(segfls);
	imwrite(GT1,['SED2_GT1\',name,'.png']);
	
	% Ground Truth 2: approved by more than half
	GT2 = (segmap/length(segfls)) > 0.5;
	imwrite(GT2,['SED2_GT2\',name,'.png']);
	
	% clear
	clear segmap;
end

