%SED2_GT generates the binary masks of the evaluation database SED2 for saliency evaluation. 
%
% 	If you use this code or data, please cite our paper: http://www.loujing.com/rpc-saliency/
% 
% 
% 	Folders:
%   --------------------------------------------
% 	SED2:		Original evaluation database (http://www.wisdom.weizmann.ac.il/~vision/Seg_Evaluation_DB/index.html)
% 	SED2_GT1:	Ground Truth approved unanimously (recommendation)
% 	SED2_GT2:	Ground Truth approved by more than half
%
%
% 	Acknowledgments:
%   --------------------------------------------
% 	I would like to thank Dr. Ming-Ming Cheng (http://mmcheng.net) for his helpful suggestions.
%
% 
%   References:
%   --------------------------------------------
% 	[1] S. Alpert, M. Galum, R. Basri, and A. Brandt, "Image segmentation by probabilistic bottom-up aggregation and cue integration," in Proc. IEEE Conf. Comput. Vis. Pattern Recognit., 2007, pp. 1�C8.
% 	[2] A. Borji, D. N. Sihite, and L. Itti, "Salient object detection: A benchmark," in Proc. Eur. Conf. Comput. Vis., 2012, pp. 414�C429.
%
% 
% 	Jing Lou (¥��), http://www.loujing.com
% 